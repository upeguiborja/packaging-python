import hello_world

# Invokes methods from package
hello_world.main()
hello_world.sayHello()
