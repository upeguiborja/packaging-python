def sayHello():
    print('Hello World')

def main():
    sayHello()
