import hello_world

# Invokes methods from package
hello-world.main()
hello-world.sayHello()
