__version__ = '0.1.0'

def sayHello():
    print('Hello World')

def main():
    sayHello()
